package use_case.search_player;

public interface SearchPlayerInputBoundary {
    void execute(SearchPlayerInputData inputData);
}
