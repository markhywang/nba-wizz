package use_case.ask_question;

public interface AskQuestionInputBoundary {
    void execute(AskQuestionInputData askQuestionInputData);
}
