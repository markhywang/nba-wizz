package use_case.sort;

public interface SortInputBoundary {
    void execute(SortInputData inputData);
}
