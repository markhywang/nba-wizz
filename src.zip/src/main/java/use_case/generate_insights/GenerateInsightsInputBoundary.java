package use_case.generate_insights;

public interface GenerateInsightsInputBoundary {
    void execute(GenerateInsightsInputData generateInsightsInputData);
}
