package use_case.compare_players;

public interface ComparePlayersInputBoundary {
    void execute(ComparePlayersInputData comparePlayersInputData);
}
