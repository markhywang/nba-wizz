package use_case.authentication.signup;

public interface SignupInputBoundary {
    void execute(SignupInputData inputData);
    void switchToLogin();
}


