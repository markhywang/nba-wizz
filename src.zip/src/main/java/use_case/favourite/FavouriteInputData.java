package use_case.favourite;

public class FavouriteInputData {
    String playerName;
    public FavouriteInputData(String playerName) {
        this.playerName = playerName;
    }
}
