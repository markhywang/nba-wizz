package use_case.compare;

public interface CompareInputBoundary {
    void execute(CompareInputData inputData);
    void switchToMainMenu();
}
